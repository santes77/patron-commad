package patternCommand;

public abstract class Command{
    public abstract void execute(Receiver receiver);
}