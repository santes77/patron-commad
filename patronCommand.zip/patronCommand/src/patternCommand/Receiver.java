package patternCommand;

public abstract class Receiver {
    public abstract void doAction();
}
