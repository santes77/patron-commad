package patternCommand;

public class ConcreteReceiver extends Receiver{

    @Override
    public void doAction() {
        System.out.println("Action on CONCRETE receiver");
    }
}
